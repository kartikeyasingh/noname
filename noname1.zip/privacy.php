<html>
<head><title>Privacy</title>
<link rel="shortcut icon" href="logo_n.jpg"></link>
</head>
<body>
<div style="width:100%;position:relative;">
<div id="div_top_bar" style="width:1350px;height:150px;background-color:;border-bottom-style:;border-width:3px;border-color:rgb(150,150,150);box-shadow:5px 5px 5px #808080">
<a href="/" ><div style="width:100px;height:100px;margin-left:100px;float:left"><img src="images/fbm_logo5.jpg" style="border-style:solid;border-color:white;border-radius:2px;"  width="100" height="100"/></div></a>
<div style="width:1150px;height:150px;float:right;">
<div style="width:500px;height:70px;float:right;background-color:;margin-right:100px">
<a href="/" style="text-decoration:none;color:gray;font-size:60px;font-family:Lucida calligraphy;">NoName.com</a>
</div>
<div style="width:900px;height:80px;float:right;background-color:">
<div style="width:400px;height:80px;float:left;"><a href="index.php" style="text-decoration:none;color:gray;font-size:40px;font-family:Lucida calligraphy;">confess anything</a></div>
<div style="width:400px;height:80px;float:right;"><a href="chat.php" style="text-decoration:none;color:gray;font-size:40px;font-family:Lucida calligraphy;">chat to strangers</a></div>
</div>
</div>
</div>
<div style="width:450px;height:50px;margin-left:225px;margin-top:100px;color:gray;font-family:Lucida calligraphy;font-size:25px;">
Sorry This Page is under construction!
</div>



<div style="1350px;height:300px;"></div>
<div style="width:1350px;height:100px;background:url('images/gradientbottom.jpg');font-family:Lucida calligraphy;font-size:17px;color:gray;">

<div style="width:1000px;height:30px;margin-left:275px;margin-top:px;">
This website needs your suggestions, please provide them in feedback section !</div>
<div style="width:1000px;height:30px;margin-left:345px;margin-top:20px;word-spacing:50px">
<a href="about.php" style="text-decoration:none">AboutUS</a>
 | <a href="feedback.php" style="text-decoration:none">Feedback</a>
 | <a href="copyright.php" style="text-decoration:none">Copyright</a>
 | <a href="privacy.php" style="text-decoration:none">Privacy</a>
</div>
</div>
</div>